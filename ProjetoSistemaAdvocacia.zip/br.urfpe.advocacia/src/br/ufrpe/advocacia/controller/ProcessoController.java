package br.ufrpe.advocacia.controller;

public class ProcessoController {

}
