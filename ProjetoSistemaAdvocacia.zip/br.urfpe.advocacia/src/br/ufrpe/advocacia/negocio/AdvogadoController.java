package br.ufrpe.advocacia.negocio;

public class AdvogadoController {

}
