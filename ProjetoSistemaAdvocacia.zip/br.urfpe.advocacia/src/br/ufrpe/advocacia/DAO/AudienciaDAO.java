package br.ufrpe.advocacia.DAO;


public class AudienciaDAO extends Repositorio {
	
	private static AudienciaDAO instance = null;
	
	public static AudienciaDAO getInstance()
	{
		if(instance == null)
		{
			instance = new AudienciaDAO();
		}
		return instance;
	}
	
	private AudienciaDAO() {
		super();
}
	
}

