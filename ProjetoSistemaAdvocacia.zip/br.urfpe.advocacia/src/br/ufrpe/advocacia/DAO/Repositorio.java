package br.ufrpe.advocacia.DAO;

import java.util.ArrayList;

public abstract class Repositorio {

	
	private ArrayList<Object> repositorios;
	
	protected Repositorio()
	{
		this.repositorios = new ArrayList<>();
	}
			
	
	public void cadastrar(Object o){
		repositorios.add(o);
	}
	
	public int buscar(Object o){
		 return repositorios.indexOf(o);
	}
	
	public boolean remover(Object o){
		boolean resultado = false;
		if(repositorios.remove(o)){
			resultado = true;
		}
		return resultado;
	}
	
	public boolean upDate(Object o1, Object o2){
		boolean resultado = false;
		if(repositorios.indexOf(o2) != -1)
		{
			repositorios.add(repositorios.indexOf(o2), o1);
			resultado = true;
		}
		return resultado;
	}
	
	
	
}
