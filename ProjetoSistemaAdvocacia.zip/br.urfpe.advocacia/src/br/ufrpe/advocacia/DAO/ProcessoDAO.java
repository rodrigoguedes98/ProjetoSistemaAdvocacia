package br.ufrpe.advocacia.DAO;


public class ProcessoDAO extends Repositorio{

private static ProcessoDAO instance = null;
	
	
	public static ProcessoDAO getInstance()
	{
		if(instance == null)
		{
			instance = new ProcessoDAO();
		}
		return instance;
	}
	
	private ProcessoDAO() {
		super();
		
	}

}
