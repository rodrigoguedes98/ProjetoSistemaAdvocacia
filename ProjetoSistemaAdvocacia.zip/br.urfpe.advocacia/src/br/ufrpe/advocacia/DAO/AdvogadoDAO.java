package br.ufrpe.advocacia.DAO;

public class AdvogadoDAO extends Repositorio
{
	private static AdvogadoDAO instance = null;
	
	public static AdvogadoDAO getInstance()
	{
		if(instance == null)
		{
			instance = new AdvogadoDAO();
		}
		return instance;
	}
	
	private AdvogadoDAO() {
		super();
	}
}
