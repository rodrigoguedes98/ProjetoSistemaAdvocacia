package br.ufrpe.advocacia.DAO;


public class PessoaDAO extends Repositorio{

private static PessoaDAO instance = null;
	
	public static PessoaDAO getInstance()
	{
		if(instance == null)
		{
			instance = new PessoaDAO();
		}
		return instance;
	}
	private PessoaDAO() {
		super();
	}
}
