package br.ufrpe.advocacia.beans;

import java.time.LocalDate;

public class Advogado extends Pessoa {
	
	private Login login;

	public Advogado(String nome, String cpf, LocalDate dataNasc, Login login) {
		super(nome, cpf, dataNasc);
		this.login = login;
	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}
	
	@Override
	public String toString()
	{
		return String.format("ADVOGADO:\nNome: %s \nCPF: %s \nData de Nascimento: %s \nIdade: %i \nID: %l"
				, this.getNome(), this.getCpf(), this.getDataNasc().toString(), this.getIdade(), this.getId());
	}
	
}
