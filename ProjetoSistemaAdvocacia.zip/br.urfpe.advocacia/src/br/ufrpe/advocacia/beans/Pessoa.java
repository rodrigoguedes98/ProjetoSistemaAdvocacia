package br.ufrpe.advocacia.beans;

import java.time.LocalDate;
import java.time.Period;

public class Pessoa {
	
	private static long nextIDP = 1;
	private String nome;
	private String cpf;
	private LocalDate dataNasc;
	private long id;
	private int idade;
	
	public Pessoa(String nome, String cpf, LocalDate dataNasc) {
		this.nome = nome;
		this.cpf = cpf;
		this.dataNasc = dataNasc;
		this.id = nextIDP++;
		this.idade = Period.between(this.dataNasc, LocalDate.now()).getYears();
	}
	
	
	public int getIdade() {
		return idade;
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public LocalDate getDataNasc() {
		return dataNasc;
	}
	public void setDataNasc(LocalDate dataNasc) {
		this.dataNasc = dataNasc;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return String.format("Nome: %s \nCPF: %s \nData de Nascimento: %s \nIdade: %i \nID: %l"
				, this.getNome(), this.getCpf(), this.getDataNasc().toString(), this.getIdade(), this.getId());
	}
	
	
	
	
	
}
