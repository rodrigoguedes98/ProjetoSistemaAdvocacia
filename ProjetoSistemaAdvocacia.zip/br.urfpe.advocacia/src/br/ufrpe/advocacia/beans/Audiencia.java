package br.ufrpe.advocacia.beans;

import java.time.LocalDateTime;

public class Audiencia {

	private static long nextIDA = 1;
	private Pessoa cliente;
	private Pessoa advogado;
	private LocalDateTime dataHora;
	private Pessoa juiz;
	private long id;
	
	public Audiencia(Pessoa cliente, Pessoa advogado, LocalDateTime dataHora, Pessoa juiz, long id) {
		this.cliente = cliente;
		this.advogado = (Advogado)advogado;
		this.dataHora = dataHora;
		this.juiz = juiz;
		this.id = nextIDA++;
	}

	

	public Pessoa getCliente() {
		return cliente;
	}

	public void setCliente(Pessoa cliente) {
		this.cliente = cliente;
	}

	public Pessoa getAdvogado() {
		return advogado;
	}

	public void setAdvogado(Pessoa advogado) {
		this.advogado = advogado;
	}

	public LocalDateTime getDataHora() {
		return dataHora;
	}

	public void setDataHora(LocalDateTime dataHora) {
		this.dataHora = dataHora;
	}

	public Pessoa getJuiz() {
		return juiz;
	}

	public void setJuiz(Pessoa juiz) {
		this.juiz = juiz;
	}

	public long getId() {
		return id;
	}
	
	
	@Override
	public String toString() {
		String resultado = "";
		resultado += "Cliente: " + this.getCliente();
		resultado += "\nAdvogado: " + this.getAdvogado();
		resultado += "\nData da audi�ncia: " + this.getDataHora();
		resultado += "\nJuiz: " + this.getJuiz();
		
		return resultado;
	}
	
}




