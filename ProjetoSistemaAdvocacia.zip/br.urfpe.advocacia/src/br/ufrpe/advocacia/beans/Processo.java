package br.ufrpe.advocacia.beans;

import java.util.ArrayList;

public class Processo {
	
	private  static  long NextIDPo =  1;
	
	private Pessoa cliente;
	private Pessoa advogado;
	private String descri��o;
	private ArrayList<Audiencia> audiencia;
	private long id;
	
	public Processo(Pessoa cliente, String descri��o, Pessoa advogado) 
	{
		this.advogado = (Advogado)advogado;
		this.cliente = cliente;
		this.descri��o = descri��o;
		this.audiencia = new ArrayList<>();
		this.id = NextIDPo++;
	}

	public Pessoa getCliente() {
		return cliente;
	}

	public void setCliente(Pessoa cliente) {
		this.cliente = cliente;
	}

	public Pessoa getAdvogado() {
		return advogado;
	}

	public void setAdvogado(Pessoa advogado) {
		this.advogado = advogado;
	}

	public String getDescri��o() {
		return descri��o;
	}

	public void setDescri��o(String descri��o) {
		this.descri��o = descri��o;
	}

	public ArrayList<Audiencia> getAudiencia() {
		return audiencia;
	}

	public void setAudiencia(ArrayList<Audiencia> audiencia) {
		this.audiencia = audiencia;
	}

	public long getId() {
		return id;
	}
	
	@Override
	public String toString()
	{
		String resultado = "";
		resultado += "Cliente: " + this.getCliente();
		resultado += "\nAdvogado: " + this.getAdvogado();
		resultado += "\n Descri��o: " + this.getDescri��o();
		resultado += "\nDias das audiencias: ";
		for (Audiencia audiencia2 : audiencia) {
			resultado += audiencia2.getDataHora(); 
		}
		return resultado;
	}

	
	
	
}
