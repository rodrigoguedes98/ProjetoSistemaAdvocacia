package Main;
import java.time.LocalDate;


import br.ufrpe.advocacia.DAO.AdvogadoDAO;
import br.ufrpe.advocacia.beans.Advogado;
import br.ufrpe.advocacia.beans.Login;

public class Main {
	public static void main(String args[]){
		
	
	Advogado teste = new Advogado("teste","teste",LocalDate.now(), new Login("teste","teste"));
	
	teste.setCpf("06502419");
	teste.setNome("Lucas");
	teste.setLogin(new Login("lucas","23142"));
	
	
	
	AdvogadoDAO advogadoDAO = AdvogadoDAO.getInstance();
	
	
	
	System.out.println(teste);
	
	}
}